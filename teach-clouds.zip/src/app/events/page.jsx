import React from 'react'

const EventsPage = () => {
  return (
    <div>EventsPage</div>
  )
}

export default EventsPage