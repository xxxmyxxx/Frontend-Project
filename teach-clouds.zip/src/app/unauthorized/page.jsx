import React from 'react'

const UnauthorizedPage = () => {
  return (
    <div>UnauthorizedPage</div>
  )
}

export default UnauthorizedPage