const Spacer = ({ height = 100 }) => {
	return <div style={{ height: `${height}px` }}></div>;
};
export default Spacer;
